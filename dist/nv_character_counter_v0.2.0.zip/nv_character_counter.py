"""Alternative word count plugin class for novelibre.

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_character_counter
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import re


class CharacterCounter:

    XML_PATTERN = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')

    def get_word_count(self, text):
        return len(self.XML_PATTERN.sub('', text.strip()))
from abc import ABC, abstractmethod



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller



class Plugin(PluginBase):
    VERSION = '0.2.0'
    API_VERSION = '5.30'
    DESCRIPTION = 'Replace word count with character count'
    URL = 'https://github.com/peter88213/nv_character_counter'

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self._mdl.nvService.change_word_counter(CharacterCounter())

