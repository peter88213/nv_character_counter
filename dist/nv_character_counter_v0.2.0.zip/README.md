[Project homepage](https://github.com/peter88213/nv_character_counter) > Instructions for use

--- 

A [novelibre](https://github.com/peter88213/novelibre/) plugin that replaces the built-in word counter by a character counter. 

---

# Installation

If [novelibre](https://github.com/peter88213/novelibre/) is installed, the setup script *setup.pyw* installs the *nv_character_counter* plugin in the *novelibre* plugin directory.

---

# License

This is Open Source software, and the *nv_character_counter* plugin is licensed under GPLv3. See the
[GNU General Public License website](https://www.gnu.org/licenses/gpl-3.0.en.html) for more
details, or consult the [LICENSE](https://github.com/peter88213/nv_character_counter/blob/main/LICENSE) file.
